package com.example.cyphergame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ml extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mllayout);
    }
}
